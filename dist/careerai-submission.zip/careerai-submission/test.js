/**
 * CyberCareer — Sprint 1 Test Suite
 * Run: node tests/test.js
 * No external test framework needed — pure Node.js
 */

const zlib   = require('zlib');
const crypto = require('crypto');
const agents = require('./server/agents.js');
const reasoning = require('./server/reasoning.js');
const dedup  = require('./server/dedup.js');
const rerank = require('./rerank.js');
const { buildReport } = require('./server/report.js');
const SecurityLearning = require('./security-learning.js');
const embeddings = require('./server/embeddings.js');
const graph = require('./server/graph.js');
const skillMatcher = require('./skill-matcher.js');
const { SECURITY_GROUPS } = require('./security-skills.js');

// ── Colour helpers ────────────────────────────────────────────────────────
const c = {
  green:  s => `\x1b[32m${s}\x1b[0m`,
  red:    s => `\x1b[31m${s}\x1b[0m`,
  yellow: s => `\x1b[33m${s}\x1b[0m`,
  bold:   s => `\x1b[1m${s}\x1b[0m`,
  dim:    s => `\x1b[2m${s}\x1b[0m`,
  cyan:   s => `\x1b[36m${s}\x1b[0m`,
};

// ── Mini test runner ──────────────────────────────────────────────────────
let passed = 0, failed = 0, skipped = 0;
const results = [];

function test(name, fn) {
  try {
    fn();
    passed++;
    results.push({ status: 'pass', name });
    process.stdout.write(c.green('  ✓ ') + c.dim(name) + '\n');
  } catch (err) {
    failed++;
    results.push({ status: 'fail', name, error: err.message });
    process.stdout.write(c.red('  ✗ ') + name + '\n');
    process.stdout.write(c.red('    → ') + err.message + '\n');
  }
}

function skip(name) {
  skipped++;
  results.push({ status: 'skip', name });
  process.stdout.write(c.yellow('  ⊘ ') + c.dim(name) + ' (skipped)\n');
}

function section(name) {
  console.log('\n' + c.bold(c.cyan('▸ ' + name)));
}

function assert(condition, message) {
  if (!condition) throw new Error(message || 'Assertion failed');
}

function assertEqual(actual, expected, label) {
  if (actual !== expected) {
    throw new Error(`${label || 'assertEqual'}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
  }
}

function assertIncludes(arr, item, label) {
  if (!arr.includes(item)) {
    throw new Error(`${label || 'assertIncludes'}: expected array to include ${JSON.stringify(item)}, got [${arr.join(', ')}]`);
  }
}

// ── Copy only the pure functions from server.js (no I/O, no network) ─────

// --- normalize & findSkills ---
const skillGroups = [
  { category: 'Core cybersecurity skills', skills: [
    { key: 'network security',       label: 'Network security' },
    { key: 'cryptography',           label: 'Cryptography' },
    { key: 'incident response',      label: 'Incident response' },
    { key: 'risk assessment',        label: 'Risk assessment' },
    { key: 'vulnerability analysis', label: 'Vulnerability analysis' },
  ]},
  { category: 'Technical skills', skills: [
    { key: 'linux',                     label: 'Linux administration' },
    { key: 'cloud security',            label: 'Cloud security' },
    { key: 'penetration testing',       label: 'Penetration testing' },
    { key: 'web application security',  label: 'Web application security' },
    { key: 'python',                    label: 'Python programming' },
  ]},
  { category: 'Career skills', skills: [
    { key: 'communication',      label: 'Communication' },
    { key: 'teamwork',           label: 'Teamwork' },
    { key: 'documentation',      label: 'Technical documentation' },
    { key: 'problem solving',    label: 'Problem solving' },
    { key: 'project management', label: 'Project management' },
  ]},
];

const roles = [
  { name: 'SOC Analyst',              required: ['network security', 'incident response', 'linux', 'communication'] },
  { name: 'Cloud Security Engineer',  required: ['cloud security', 'network security', 'linux', 'documentation'] },
  { name: 'Penetration Tester',       required: ['penetration testing', 'web application security', 'python', 'linux'] },
  { name: 'Cybersecurity Consultant', required: ['risk assessment', 'vulnerability analysis', 'communication', 'problem solving'] },
];

// Exercise the real matcher rather than a copy of it.
const normalize = skillMatcher.normalize;
const findSkills = (text) => skillMatcher.findSkills(text, skillGroups);

function analyzeRoles(foundKeys) {
  return roles
    .map(role => {
      const missing = role.required.filter(s => !foundKeys.includes(s));
      return {
        name:    role.name,
        matched: role.required.length - missing.length,
        total:   role.required.length,
        missing,
        score:   (role.required.length - missing.length) / role.required.length,
      };
    })
    .filter(r => r.score >= 0.4)
    .sort((a, b) => b.score - a.score);
}

function hashPassword(plaintext) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(plaintext, salt, 32).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(plaintext, stored) {
  if (!stored.includes(':')) return stored === plaintext;
  const [salt, expected] = stored.split(':');
  const actual = crypto.scryptSync(plaintext, salt, 32).toString('hex');
  return actual === expected;
}

function decodePdfStr(s) {
  return s
    .replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t')
    .replace(/\\\(/g, '(').replace(/\\\)/g, ')').replace(/\\\\/g, '\\');
}

function stripHtml(str) {
  return (str || '').replace(/<[^>]*>/g, ' ').replace(/\s{2,}/g, ' ').trim();
}

function kwTokens(keyword) {
  return (keyword || '').toLowerCase().split(/\s+/).filter(t => t.length > 2);
}

function matchesKeyword(tokens, ...fields) {
  if (!tokens.length) return true;
  const hay = fields.map(f => (f || '').toLowerCase()).join(' ');
  return tokens.some(t => hay.includes(t));
}

function jobMatchesProfile(job, profileText) {
  if (!profileText) return true;
  const normalizedProfile = normalize(profileText);
  const profileSkills = findSkills(profileText).map(s => s.key);
  const combinedJobText = [job.title, job.company, job.location, job.description]
    .filter(Boolean).join(' ').toLowerCase();
  if (profileSkills.length > 0) return profileSkills.some(s => combinedJobText.includes(s));
  return normalizedProfile.split(' ').some(t => t && combinedJobText.includes(t));
}

// ─────────────────────────────────────────────────────────────────────────
// TESTS
// ─────────────────────────────────────────────────────────────────────────

console.log(c.bold('\n CyberCareer — Sprint 1 Test Suite\n') + c.dim('  Running all unit tests…'));

// ── 1. normalize() ────────────────────────────────────────────────────────
section('normalize()');

test('lowercases all text', () => {
  assertEqual(normalize('Linux Administration'), 'linux administration', 'lowercase');
});

test('strips punctuation chars . , ; : ( ) - /', () => {
  const result = normalize('Python, Linux; Security: (good)-test/ok');
  assert(!result.includes(','), 'comma removed');
  assert(!result.includes(';'), 'semicolon removed');
  assert(!result.includes(':'), 'colon removed');
  assert(!result.includes('('), 'paren removed');
  assert(!result.includes('-'), 'dash removed');
  assert(!result.includes('/'), 'slash removed');
});

test('preserves spaces and alphanumeric chars', () => {
  const result = normalize('network security 2024');
  assert(result.includes('network security'), 'kept words');
  assert(result.includes('2024'), 'kept numbers');
});

// ── 2. findSkills() ───────────────────────────────────────────────────────
section('findSkills()');

test('detects single skill in plain text', () => {
  const found = findSkills('I have experience with python scripting');
  assertIncludes(found.map(s => s.key), 'python', 'python detected');
});

test('detects multiple skills', () => {
  const cv = 'I work with linux systems, network security, and penetration testing';
  const found = findSkills(cv);
  const keys  = found.map(s => s.key);
  assertIncludes(keys, 'linux',              'linux detected');
  assertIncludes(keys, 'network security',   'network security detected');
  assertIncludes(keys, 'penetration testing','penetration testing detected');
});

test('returns empty array for text with no skills', () => {
  const found = findSkills('I love cooking pasta and hiking on weekends');
  assertEqual(found.length, 0, 'no skills found');
});

// ── 2b. Matching over the full security taxonomy ──────────────────────────
const secKeys = (text) => skillMatcher.findSkills(text, SECURITY_GROUPS).map(s => s.key);

test('respects word boundaries (no substring false positives)', () => {
  // "admiNISTrateur" must not detect the NIST framework.
  const keys = secKeys('Administrateur systeme Linux, administration reseau');
  assert(!keys.includes('nist'), 'nist not detected inside "administrateur"');
});

test('detects keys whose punctuation normalize() strips', () => {
  const keys = secKeys('Experience in Cross-Site Scripting, TCP/IP and Single Sign-On');
  assertIncludes(keys, 'cross-site scripting', 'xss key reachable');
  assertIncludes(keys, 'tcp/ip',               'tcp/ip key reachable');
  assertIncludes(keys, 'single sign-on',       'sso key reachable');
});

test('detects German and French surface forms via aliases', () => {
  assertIncludes(secKeys('Erfahrung mit DSGVO'),        'gdpr', 'DSGVO → gdpr');
  assertIncludes(secKeys('Conformite au RGPD'),         'gdpr', 'RGPD → gdpr');
  assertIncludes(secKeys('Penetrationstests bei Bosch'),'penetration testing', 'Penetrationstests → pentest');
  assertIncludes(secKeys('J ai mene des pentests'),     'penetration testing', 'pentests → pentest');
});

test('log correlation counts as log analysis, never as SIEM', () => {
  const keys = secKeys('J ai fait de la correlation de logs pendant mon stage');
  assertIncludes(keys, 'log analysis', 'correlation de logs → log analysis');
  assert(!keys.includes('siem'), 'siem stays a gap: correlating logs is not SIEM tooling');
});

test('detects acronyms via aliases', () => {
  assertIncludes(secKeys('Deployed MFA and SSO with Keycloak'), 'multi-factor authentication', 'MFA');
  assertIncludes(secKeys('Hardened the WAF and reviewed XSS'),  'web application firewall',    'WAF');
});

test('is case-insensitive', () => {
  const found = findSkills('Expert in CRYPTOGRAPHY and LINUX');
  const keys  = found.map(s => s.key);
  assertIncludes(keys, 'cryptography', 'crypto uppercase');
  assertIncludes(keys, 'linux',        'linux uppercase');
});

test('handles punctuation around skills', () => {
  const found = findSkills('Skills: python, linux; incident response.');
  const keys  = found.map(s => s.key);
  assertIncludes(keys, 'python',           'python with comma');
  assertIncludes(keys, 'linux',            'linux with semicolon');
  assertIncludes(keys, 'incident response','incident response with dot');
});

test('detects all 15 skills when all present', () => {
  const allSkillText = skillGroups.flatMap(g => g.skills.map(s => s.key)).join(' ');
  const found = findSkills(allSkillText);
  assertEqual(found.length, 15, 'all 15 skills detected');
});

test('no duplicate skills in result', () => {
  const found = findSkills('python python python linux linux');
  const keys  = found.map(s => s.key);
  const unique = new Set(keys);
  assertEqual(keys.length, unique.size, 'no duplicates');
});

// ── 3. analyzeRoles() ─────────────────────────────────────────────────────
section('analyzeRoles()');

test('returns SOC Analyst when all required skills present', () => {
  const keys = ['network security', 'incident response', 'linux', 'communication'];
  const result = analyzeRoles(keys);
  assert(result.some(r => r.name === 'SOC Analyst'), 'SOC Analyst in results');
});

test('SOC Analyst has 100% score with full match', () => {
  const keys   = ['network security', 'incident response', 'linux', 'communication'];
  const result = analyzeRoles(keys);
  const soc    = result.find(r => r.name === 'SOC Analyst');
  assertEqual(soc.score, 1, 'score is 1.0');
  assertEqual(soc.matched, 4, 'matched 4/4');
  assertEqual(soc.missing.length, 0, 'no missing skills');
});

test('filters out roles below 40% match', () => {
  const keys   = ['python']; // only matches Penetration Tester 1/4 = 25%
  const result = analyzeRoles(keys);
  assert(result.every(r => r.score >= 0.4), 'all results have score >= 0.4');
});

test('results are sorted by score descending', () => {
  const keys = ['network security', 'incident response', 'linux', 'communication',
                 'penetration testing', 'web application security', 'python'];
  const result = analyzeRoles(keys);
  for (let i = 1; i < result.length; i++) {
    assert(result[i - 1].score >= result[i].score, 'scores descending');
  }
});

test('returns empty array when no skills match any role', () => {
  const result = analyzeRoles(['teamwork']); // teamwork not in any role.required
  assertEqual(result.length, 0, 'empty result');
});

test('correctly lists missing skills', () => {
  const keys   = ['network security', 'incident response', 'linux']; // missing 'communication'
  const result = analyzeRoles(keys);
  const soc    = result.find(r => r.name === 'SOC Analyst');
  assert(soc, 'SOC Analyst found (3/4 = 75%)');
  assertIncludes(soc.missing, 'communication', 'communication listed as missing');
  assertEqual(soc.missing.length, 1, 'only 1 missing skill');
});

// ── 4. hashPassword / verifyPassword ─────────────────────────────────────
section('hashPassword() / verifyPassword()');

test('hashed password verifies correctly', () => {
  const hash = hashPassword('securePass123!');
  assert(verifyPassword('securePass123!', hash), 'correct password verifies');
});

test('wrong password fails verification', () => {
  const hash = hashPassword('correctPass');
  assert(!verifyPassword('wrongPass', hash), 'wrong password rejected');
});

test('each hash is unique (different salts)', () => {
  const h1 = hashPassword('same');
  const h2 = hashPassword('same');
  assert(h1 !== h2, 'hashes differ');
});

test('hash format contains salt:hash', () => {
  const hash = hashPassword('test');
  assert(hash.includes(':'), 'contains colon separator');
  const parts = hash.split(':');
  assertEqual(parts.length, 2, 'exactly two parts');
  assert(parts[0].length > 0, 'salt non-empty');
  assert(parts[1].length > 0, 'hash non-empty');
});

test('legacy plaintext password (no colon) verifies by equality', () => {
  assert(verifyPassword('legacy123', 'legacy123'), 'legacy plaintext match');
  assert(!verifyPassword('wrong', 'legacy123'), 'legacy plaintext mismatch');
});

// ── 5. decodePdfStr() ────────────────────────────────────────────────────
section('decodePdfStr()');

test('decodes \\n to newline', () => {
  assertEqual(decodePdfStr('line1\\nline2'), 'line1\nline2', 'newline');
});

test('decodes escaped parentheses', () => {
  assertEqual(decodePdfStr('\\(hello\\)'), '(hello)', 'parens');
});

test('decodes escaped backslash', () => {
  assertEqual(decodePdfStr('path\\\\file'), 'path\\file', 'backslash');
});

test('leaves normal text untouched', () => {
  assertEqual(decodePdfStr('Hello World'), 'Hello World', 'plain text');
});

// ── 6. stripHtml() ───────────────────────────────────────────────────────
section('stripHtml()');

test('removes basic HTML tags', () => {
  const result = stripHtml('<p>Hello <strong>World</strong></p>');
  assert(!result.includes('<'), 'no < remaining');
  assert(!result.includes('>'), 'no > remaining');
  assert(result.includes('Hello'), 'text preserved');
  assert(result.includes('World'), 'inner text preserved');
});

test('collapses multiple spaces', () => {
  const result = stripHtml('<p>   hello   </p>');
  assert(!result.includes('   '), 'no triple spaces');
});

test('handles null / undefined gracefully', () => {
  assertEqual(stripHtml(null),      '', 'null → empty');
  assertEqual(stripHtml(undefined), '', 'undefined → empty');
  assertEqual(stripHtml(''),        '', 'empty → empty');
});

// ── 7. kwTokens() ────────────────────────────────────────────────────────
section('kwTokens()');

test('splits keyword into lowercase tokens', () => {
  const tokens = kwTokens('IT Security');
  assertIncludes(tokens, 'security', 'security token');
});

test('filters tokens shorter than 3 chars', () => {
  const tokens = kwTokens('IT Security AI');
  assert(!tokens.includes('it'), 'it filtered');
  assert(!tokens.includes('ai'), 'ai filtered');
  assertIncludes(tokens, 'security', 'security kept');
});

test('returns empty array for empty string', () => {
  assertEqual(kwTokens('').length, 0, 'empty');
  assertEqual(kwTokens(null).length, 0, 'null');
});

// ── 8. matchesKeyword() ──────────────────────────────────────────────────
section('matchesKeyword()');

test('returns true when any token matches', () => {
  const tokens = kwTokens('python security');
  assert(matchesKeyword(tokens, 'Python developer job'), 'python matches');
});

test('returns false when no token matches', () => {
  const tokens = kwTokens('kubernetes golang');
  assert(!matchesKeyword(tokens, 'Java Spring developer'), 'no match');
});

test('returns true when tokens array is empty (match-all)', () => {
  assert(matchesKeyword([], 'anything'), 'empty tokens = match all');
});

// ── 9. jobMatchesProfile() ───────────────────────────────────────────────
section('jobMatchesProfile()');

test('returns true when profile is empty', () => {
  const job = { title: 'SOC Analyst', company: 'Acme', location: 'Berlin', description: 'network security' };
  assert(jobMatchesProfile(job, ''), 'empty profile matches all');
});

test('matches job when profile skills appear in job text', () => {
  const job = { title: 'Penetration Tester', company: 'SecCo', location: 'Germany', description: 'python linux' };
  const profile = 'I am experienced in linux and python scripting';
  assert(jobMatchesProfile(job, profile), 'profile skills match job');
});

test('does not match job unrelated to profile', () => {
  const job = { title: 'Java Developer', company: 'Dev Inc', location: 'Munich', description: 'spring boot microservices' };
  const profile = 'Expert in network security, incident response, and linux';
  assert(!jobMatchesProfile(job, profile), 'unrelated job not matched');
});

// ── 10. Edge cases ────────────────────────────────────────────────────────
section('Edge cases & robustness');

test('findSkills on empty string returns []', () => {
  assertEqual(findSkills('').length, 0, 'empty string');
});

test('analyzeRoles on empty array returns []', () => {
  assertEqual(analyzeRoles([]).length, 0, 'empty keys');
});

test('normalize on empty string returns empty string', () => {
  assertEqual(normalize(''), '', 'empty normalize');
});

test('findSkills detects multi-word skills (web application security)', () => {
  const found = findSkills('I specialize in web application security testing');
  assertIncludes(found.map(s => s.key), 'web application security', 'multi-word skill');
});

test('score is between 0 and 1 for all roles', () => {
  const keys = ['network security', 'linux'];
  const result = analyzeRoles(keys);
  result.forEach(r => {
    assert(r.score >= 0 && r.score <= 1, `score in [0,1] for ${r.name}`);
  });
});

// ── 11. Multi-Agent Architecture (server/agents.js) ──────────────────────
// Async-aware test helper for the orchestration pipeline.
async function atest(name, fn) {
  try {
    await fn();
    passed++;
    process.stdout.write(c.green('  ✓ ') + c.dim(name) + '\n');
  } catch (err) {
    failed++;
    process.stdout.write(c.red('  ✗ ') + name + '\n' + c.red('    → ') + err.message + '\n');
  }
}

// Dependency bundle injected into the agents (mirrors server.js buildAgentDeps).
const agentDeps = {
  findSkills,
  analyzeRoles,
  allSkills: () => skillGroups.flatMap(g => g.skills),
  scoreJob: (job, analysis) => {
    const fk = analysis.foundSkills.map(s => s.key);
    const text = `${job.title || ''} ${job.description || ''}`.toLowerCase();
    const matched = fk.filter(k => text.includes(k));
    return { score: fk.length ? matched.length / fk.length : 0, breakdown: { matched } };
  },
};

// ── 11. Fuzzy cross-source deduplication (server/dedup.js) ───────────────
section('Fuzzy deduplication');

test('similarity: identical strings = 1', () => {
  assertEqual(dedup.similarity('python developer', 'python developer'), 1, 'identical');
});

test('similarity: unrelated strings are low', () => {
  assert(dedup.similarity('python developer', 'marketing manager') < 0.4, 'low similarity');
});

test('isDuplicate: merges (m/w/d) and company-form variants', () => {
  const a = { title: 'Python Developer (m/w/d)', company: 'Acme GmbH' };
  const b = { title: 'Python Developer', company: 'Acme AG' };
  assert(dedup.isDuplicate(a, b).dup, 'recognised as duplicate');
});

test('isDuplicate: keeps genuinely different jobs separate', () => {
  const a = { title: 'Python Developer', company: 'Acme' };
  const b = { title: 'Marketing Manager', company: 'Globex' };
  assert(!dedup.isDuplicate(a, b).dup, 'not a duplicate');
});

test('dedupeJobs: merges cross-source duplicates and records also_on', () => {
  const jobs = [
    { title: 'SOC Analyst (m/w/d)', company: 'SecureOps GmbH', board: 'Bundesagentur' },
    { title: 'SOC Analyst', company: 'SecureOps AG', board: 'LinkedIn' },
    { title: 'Penetration Tester', company: 'RedTeam', board: 'Remotive' },
  ];
  const out = dedup.dedupeJobs(jobs);
  assertEqual(out.length, 2, 'two unique jobs');
  assertIncludes(out[0].also_on, 'LinkedIn', 'duplicate source recorded');
});

test('dedupeJobs: handles empty input', () => {
  assertEqual(dedup.dedupeJobs([]).length, 0, 'empty');
});

// ── 12. Outcome-based re-ranking (rerank.js) ─────────────────────────────
section('Outcome-based re-ranking');

const detectKeys = (text) => findSkills(text).map(s => s.key);

test('successSignal: aggregates skills only from interview/offer apps', () => {
  const apps = [
    { status: 'interview', title: 'SOC Analyst with linux and python' },
    { status: 'offer',     title: 'Penetration tester python' },
    { status: 'applied',   title: 'Cloud security engineer' }, // ignored (not positive)
  ];
  const sig = rerank.successSignal(apps, detectKeys);
  assertEqual(sig.count, 2, 'only positive apps counted');
  assert(sig.skills['python'] >= 2, 'python aggregated from both successes');
});

test('boostFor: rewards jobs sharing skills with past successes', () => {
  const sig = rerank.successSignal(
    [{ status: 'offer', title: 'linux python network security' }], detectKeys);
  const { points, matched } = rerank.boostFor(['python', 'linux'], sig);
  assert(points > 0, 'positive boost');
  assertIncludes(matched, 'python', 'python matched');
});

test('boostFor: no signal → no boost', () => {
  const { points } = rerank.boostFor(['python'], { count: 0, skills: {} });
  assertEqual(points, 0, 'zero boost without history');
});

test('boostFor: boost is capped at MAX_BOOST', () => {
  const skills = {}; ['a','b','c','d','e','f'].forEach(k => skills[k] = 1);
  const { points } = rerank.boostFor(['a','b','c','d','e','f'], { count: 6, skills });
  assert(points <= rerank.MAX_BOOST, 'capped at MAX_BOOST');
});

(async function runAgentTests() {
  section('Multi-Agent Architecture');

  test('registry exposes exactly 4 separated agents', () => {
    const names = agents.AGENT_REGISTRY.map(a => a.name);
    assertEqual(agents.AGENT_REGISTRY.length, 4, '4 agents');
    ['Scout', 'Matcher', 'Writer', 'Tracker'].forEach(n => assertIncludes(names, n, `${n} present`));
  });

  test('Scout agent: CV → skills, gaps and roles', () => {
    const out = agents.ScoutAgent.run({ cvText: 'linux python network security communication' }, null, agentDeps);
    assert(out.foundSkills.length >= 3, 'skills detected');
    assert(Array.isArray(out.missingSkills), 'missing skills array');
    assert(out.roles.some(r => r.name === 'SOC Analyst'), 'role-fit computed');
  });

  test('Scout agent: enforces input contract (throws on bad input)', () => {
    let threw = false;
    try { agents.ScoutAgent.run({ cvText: 42 }, null, agentDeps); } catch (_) { threw = true; }
    assert(threw, 'rejects non-string cvText');
  });

  test('Matcher agent: ranks jobs by score descending', () => {
    const analysis = agents.ScoutAgent.run({ cvText: 'python linux' }, null, agentDeps);
    const jobs = [
      { id: 'a', title: 'Receptionist', description: 'front desk' },
      { id: 'b', title: 'Python Developer', description: 'python linux backend' },
    ];
    const out = agents.MatcherAgent.run({ analysis, jobs }, null, agentDeps);
    assertEqual(out.matches[0].job.id, 'b', 'best match first');
    for (let i = 1; i < out.matches.length; i++) {
      assert(out.matches[i - 1].score >= out.matches[i].score, 'scores descending');
    }
  });

  test('Matcher agent: enforces contract (throws without analysis)', () => {
    let threw = false;
    try { agents.MatcherAgent.run({ jobs: [] }, null, agentDeps); } catch (_) { threw = true; }
    assert(threw, 'requires Scout analysis');
  });

  test('Writer agent: degrades gracefully when no writer configured', async () => {
    const out = await agents.WriterAgent.run({ profile: { name: 'X' }, job: {} }, null, {});
    assertEqual(out.generated, false, 'no document but no crash');
  });

  test('Tracker agent: CRUD via injected store', () => {
    const db = [];
    const store = {
      list: () => db,
      add: (a) => { const item = { id: '1', ...a }; db.push(item); return item; },
      update: (id, u) => Object.assign(db.find(x => x.id === id), u),
      remove: (id) => { const i = db.findIndex(x => x.id === id); if (i >= 0) db.splice(i, 1); },
    };
    agents.TrackerAgent.run({ action: 'add', payload: { title: 'SOC' } }, null, { store });
    const listed = agents.TrackerAgent.run({ action: 'list' }, null, { store });
    assertEqual(listed.applications.length, 1, 'application added & listed');
  });

  test('Tracker agent: rejects unknown action', () => {
    let threw = false;
    try { agents.TrackerAgent.run({ action: 'explode' }, null, { store: {} }); } catch (_) { threw = true; }
    assert(threw, 'unknown action throws');
  });

  await atest('Pipeline: Scout → Matcher communicate via shared context', async () => {
    const result = await agents.runPipeline(
      { cvText: 'python linux network security', jobs: [{ id: 'j', title: 'Python Dev', description: 'python linux' }] },
      agentDeps
    );
    assert(result.analysis && result.analysis.foundSkills.length > 0, 'Scout output present');
    assert(result.matching && result.matching.matches.length === 1, 'Matcher received jobs');
    assert(result.agentLog.some(l => l.agent === 'Scout' && l.status === 'done'), 'status log records Scout');
    assertEqual(result.ok, true, 'pipeline ok');
  });

  await atest('Pipeline: isolates a failing agent (no crash, error logged)', async () => {
    const brokenDeps = { ...agentDeps, findSkills: () => { throw new Error('boom'); } };
    const result = await agents.runPipeline({ cvText: 'x', jobs: [] }, brokenDeps);
    assertEqual(result.analysis, null, 'failed Scout returns null');
    assertEqual(result.matching, null, 'downstream Matcher skipped');
    assert(result.errors.length === 1, 'error captured');
    assertEqual(result.ok, false, 'pipeline reports failure without throwing');
  });

  // ───────────────────────────────────────────────────────────────────────
  // Skill-Gap Recommendations (Sprint-2 feature: concrete "learn Y" advice)
  // ───────────────────────────────────────────────────────────────────────
  section('Skill-Gap Recommendations');

  test('learningFor: maps a security skill to concrete resource', () => {
    const rec = SecurityLearning.learningFor({ key: 'siem', label: 'SIEM', category: 'Defensive Security / Blue Team / SOC' });
    assert(rec.key === 'siem', 'key preserved');
    assert(rec.label === 'SIEM', 'label preserved');
    assert(rec.how && rec.how.length > 0, 'how is non-empty');
    assert(rec.resource && rec.resource.length > 0, 'resource is non-empty');
    assert(rec.resource.toLowerCase().includes('splunk'), 'SIEM resource mentions Splunk');
  });

  test('learningFor: falls back to category default for unknown skill', () => {
    const rec = SecurityLearning.learningFor({ key: 'unknown-xyz', label: 'Unknown', category: 'Network Security' });
    assert(rec.how && rec.how.length > 0, 'how is non-empty (from category fallback)');
    assert(rec.resource && rec.resource.length > 0, 'resource is non-empty (from category fallback)');
  });

  test('learningFor: returns DEFAULT for unknown category', () => {
    const rec = SecurityLearning.learningFor({ key: 'xyz', label: 'Unknown', category: 'Unknown Category' });
    assert(rec.how === 'Build hands-on experience', 'DEFAULT how');
    assert(rec.resource.includes('TryHackMe'), 'DEFAULT resource mentions TryHackMe');
  });

  test('recommendGaps: prioritises skills by how many target roles require them', () => {
    const roles = [
      { name: 'SOC Analyst', score: 0.8, missing: ['siem', 'log analysis', 'incident response'] },
      { name: 'Pentester', score: 0.6, missing: ['siem', 'metasploit', 'nmap'] },
    ];
    const skillMeta = key => ({ key, label: key.toUpperCase(), category: '' });
    const recs = SecurityLearning.recommendGaps(roles, { lookup: skillMeta, topRoles: 2, limit: 8 });

    assert(recs.length > 0, 'returns recommendations');
    assert(recs[0].key === 'siem', 'siem ranked first (needed by both roles)');
    assert(recs[0].priority === 2, 'siem has priority=2 (two roles)');
    assert(recs[0].forRoles.length === 2, 'siem.forRoles has both role names');
  });

  test('recommendGaps: respects topRoles limit', () => {
    const roles = [
      { name: 'Role1', missing: ['skill1'] },
      { name: 'Role2', missing: ['skill2'] },
      { name: 'Role3', missing: ['skill3'] },
    ];
    const skillMeta = key => ({ key, label: key });
    const recs = SecurityLearning.recommendGaps(roles, { lookup: skillMeta, topRoles: 1, limit: 8 });

    assert(recs.length === 1, 'only considers top 1 role → 1 rec');
    assert(recs[0].key === 'skill1', 'recommendation is from Role1');
  });

  test('Scout agent output includes recommendations when deps.recommend injected', async () => {
    const mockRecommend = () => [
      { key: 'test', label: 'Test Skill', how: 'practice', resource: 'test platform' }
    ];
    const deps = {
      findSkills: () => [{ key: 'python', label: 'Python' }],
      analyzeRoles: () => [{ name: 'Test Role', missing: ['test'] }],
      allSkills: () => [{ key: 'python', label: 'Python' }, { key: 'test', label: 'Test Skill' }],
      recommend: mockRecommend,
    };
    const result = await agents.ScoutAgent.run({ cvText: 'python test' }, {}, deps);
    assert(Array.isArray(result.recommendations), 'recommendations is an array');
    assert(result.recommendations.length === 1, 'recommendation included');
    assert(result.recommendations[0].key === 'test', 'recommendation has correct key');
  });

  test('Scout agent gracefully omits recommendations if no recommender injected', async () => {
    const deps = {
      findSkills: () => [{ key: 'python', label: 'Python' }],
      analyzeRoles: () => [],
      allSkills: () => [{ key: 'python', label: 'Python' }],
      // no recommend dep
    };
    const result = await agents.ScoutAgent.run({ cvText: 'python' }, {}, deps);
    assert(Array.isArray(result.recommendations), 'recommendations is still an array (empty)');
    assert(result.recommendations.length === 0, 'no recommendations without injected recommender');
  });


  section('Agent reasoning layer');

  // A stub model: returns whatever the test scripted, so these exercise the guard
  // rather than a provider. The guard is the security boundary — a model that
  // invents a qualification must not be able to put it in a cover letter.
  const stubLlm = (reply) => ({ isAvailable: () => true, chat: async () => reply });
  const VOCAB = [
    { key: 'firewall', label: 'Firewall' },
    { key: 'siem', label: 'SIEM' },
    { key: 'kubernetes', label: 'Kubernetes' },
  ];
  const CV = 'Ich habe zu Hause ein Labor mit pfSense aufgebaut und den Netzwerkverkehr segmentiert. '
           + 'Im Studium Grundlagen der IT-Sicherheit, Python und Linux.';

  await atest('Scout reasoning: accepts an inferred skill backed by a verbatim CV quote', async () => {
    const out = await reasoning.inferSkills(
      { cvText: CV, foundKeys: [], vocabulary: VOCAB },
      stubLlm(JSON.stringify([
        { key: 'firewall', evidence: 'ein Labor mit pfSense aufgebaut', confidence: 0.9 },
      ])));
    assert(out && out.inferred.length === 1, 'one skill inferred');
    assert(out.inferred[0].key === 'firewall', 'the firewall skill');
    assert(out.inferred[0].evidence.includes('pfSense'), 'evidence carried through');
  });

  await atest('Scout reasoning: REJECTS a skill whose evidence is not in the CV', async () => {
    const out = await reasoning.inferSkills(
      { cvText: CV, foundKeys: [], vocabulary: VOCAB },
      stubLlm(JSON.stringify([
        { key: 'siem', evidence: 'drei Jahre Splunk im SOC', confidence: 0.95 },
      ])));
    assert(out && out.inferred.length === 0, 'nothing accepted');
    assert(out.rejected.length === 1 && /evidence/.test(out.rejected[0].why), 'rejected for missing evidence');
  });

  await atest('Scout reasoning: rejects a key outside the taxonomy', async () => {
    const out = await reasoning.inferSkills(
      { cvText: CV, foundKeys: [], vocabulary: VOCAB },
      stubLlm(JSON.stringify([{ key: 'quantum-crypto', evidence: 'pfSense', confidence: 1 }])));
    assert(out.inferred.length === 0 && out.rejected.length === 1, 'invented key refused');
  });

  await atest('Scout reasoning: no model configured leaves the analysis untouched', async () => {
    const out = await reasoning.inferSkills(
      { cvText: CV, foundKeys: [], vocabulary: VOCAB }, { isAvailable: () => false });
    assert(out === null, 'returns null so the caller keeps the deterministic result');
  });

  await atest('Scout reasoning: malformed model output does not throw', async () => {
    const out = await reasoning.inferSkills(
      { cvText: CV, foundKeys: [], vocabulary: VOCAB }, stubLlm('sorry, I cannot help'));
    assert(out === null, 'unparseable reply degrades to null');
  });

  const LONG_POSTING = 'Wir suchen eine erfahrene Fachkraft. Voraussetzung sind mindestens zehn Jahre '
    + 'Berufserfahrung im Bereich IT-Sicherheit sowie ein abgeschlossenes Studium. Kenntnisse in Python '
    + 'und Linux werden vorausgesetzt. Die Stelle ist unbefristet und in Vollzeit zu besetzen.';

  await atest('Matcher reasoning: a blocked verdict must cite the requirement', async () => {
    const v = await reasoning.adjudicate(
      { job: { title: 'Senior Analyst' }, jobDescription: LONG_POSTING, foundKeys: ['python'], score: 0.81 },
      stubLlm(JSON.stringify({ verdict: 'blocked', blockers: ['mindestens zehn Jahre Berufserfahrung'], reason: 'Junior profile.' })));
    assert(v.verdict === 'blocked' && v.blockers.length === 1, 'blocked with a cited requirement');
  });

  await atest('Matcher reasoning: "blocked" with no cited requirement is downgraded to ok', async () => {
    const v = await reasoning.adjudicate(
      { job: { title: 'Analyst' }, jobDescription: LONG_POSTING, foundKeys: [], score: 0.7 },
      stubLlm(JSON.stringify({ verdict: 'blocked', blockers: [], reason: 'feels wrong' })));
    assert(v.verdict === 'ok', 'an opinion without evidence cannot exclude a candidate');
  });

  await atest('Matcher reasoning: a posting too short to state a requirement is not judged', async () => {
    const v = await reasoning.adjudicate(
      { job: { title: 'Analyst' }, jobDescription: 'Full description on LinkedIn.', foundKeys: [], score: 0.9 },
      stubLlm(JSON.stringify({ verdict: 'blocked', blockers: ['x'], reason: 'y' })));
    assert(v === null, 'no description, no verdict');
  });

  await atest('Matcher reasoning: blocked matches are demoted, never rescored', async () => {
    const deps = {
      scoreJob: (job) => ({ score: job.s, breakdown: {} }),
      llm: { isAvailable: () => true },
      reasoning: {
        ADJUDICATE_TOP_N: 2,
        adjudicate: async ({ job }) => (job.title === 'Senior'
          ? { verdict: 'blocked', blockers: ['10 years'], reason: 'too senior' }
          : { verdict: 'ok', blockers: [], reason: '' }),
      },
    };
    const jobs = [
      { title: 'Senior', s: 0.9, description: 'x'.repeat(200) },
      { title: 'Junior', s: 0.8, description: 'x'.repeat(200) },
    ];
    const base = agents.MatcherAgent.run({ analysis: { foundKeys: [] }, jobs }, null, deps);
    assert(base.matches[0].job.title === 'Senior', 'deterministic ranking puts Senior first');
    const out = await agents.MatcherAgent.reason(base, { analysis: { foundKeys: [] } }, deps);
    assert(out.matches[0].job.title === 'Junior', 'blocked match demoted below the eligible one');
    assert(out.matches[1].score === 0.9, 'the blocked match keeps its original score');
    assert(out.blockedCount === 1, 'blocked count reported');
  });

  section('Market report');

  await atest('buildReport: aggregates skills, locations and totals', async () => {
    const jobs = [
      { title: 'Python Developer', description: 'python linux', company: 'Acme', location: 'Berlin, DE' },
      { title: 'Python Engineer',  description: 'python',       company: 'Globex', location: 'Berlin' },
      { title: 'SOC Analyst',      description: 'incident response', company: 'SecOps', location: 'Munich' },
    ];
    const report = await buildReport(jobs, { findSkills }, 'python');
    assertEqual(report.total_jobs, 3, 'counts all jobs');
    assert(report.top_skills.length > 0, 'skills aggregated');
    assert(report.top_locations.some(l => l.name === 'Berlin' && l.count === 2), 'Berlin counted twice');
    assert(typeof report.summary === 'string' && report.summary.length > 0, 'summary produced');
  });

  // ── RAG: embeddings maths (pure, no API) ─────────────────────────────────
  section('RAG — embeddings');

  await atest('cosine: identical vectors = 1, orthogonal = 0', async () => {
    assert(Math.abs(embeddings.cosine([1, 2, 3], [1, 2, 3]) - 1) < 1e-9, 'identical → 1');
    assert(Math.abs(embeddings.cosine([1, 0], [0, 1]) - 0) < 1e-9, 'orthogonal → 0');
    assertEqual(embeddings.cosine([1, 2], [1, 2, 3]), 0, 'length mismatch → 0');
  });

  await atest('relevance: calibrates raw cosine to an honest 0..1', async () => {
    assertEqual(embeddings.relevance(0.55), 0, 'at/below floor → 0');
    assertEqual(embeddings.relevance(0.40), 0, 'below floor clamps to 0');
    assertEqual(embeddings.relevance(0.82), 1, 'at/above ceil → 1');
    const mid = embeddings.relevance(0.685); // midpoint of [0.55, 0.82]
    assert(mid > 0.45 && mid < 0.55, `midpoint ≈ 0.5 (got ${mid.toFixed(3)})`);
    assert(embeddings.relevance(0.56) < embeddings.relevance(0.81), 'monotonic (preserves ranking)');
  });

  // ── LangGraph: routing + Writer⇄Critic loop (mocked LLM, deterministic) ───
  section('LangGraph — multi-agent pipeline');

  const gDeps = {
    findSkills: () => [{ key: 'siem', label: 'SIEM' }],
    analyzeRoles: () => [{ name: 'SOC Analyst', score: 0.8 }],
    allSkills: () => [{ key: 'siem', label: 'SIEM' }, { key: 'edr', label: 'EDR' }],
    scoreJob: () => ({ score: 0.8, breakdown: {} }),
    recommend: () => [],
  };
  const noRag = { isAvailable: () => false, retrieve: async () => [] };

  await atest('graph: Writer⇄Critic loop refines until the quality bar', async () => {
    let criticCalls = 0;
    const mockLlm = {
      isAvailable: () => true,
      chat: async ({ system }) => {
        if (/Critic/.test(system)) { criticCalls++; return JSON.stringify({ score: criticCalls === 1 ? 50 : 95, feedback: 'add specifics' }); }
        return 'Dear Manager, a tailored letter mentioning SIEM and Splunk.';
      },
    };
    const r = await graph.runGraph(
      { cvText: 'siem splunk', profile: { title: 'SOC' }, job: { title: 'SOC Analyst' }, jobDescription: 'monitor SIEM alerts' },
      gDeps, mockLlm, noRag,
    );
    assert(r.coverLetter.length > 0, 'produces a letter');
    assertEqual(r.revisions, 2, 'looped once (score 50 → refine → 95)');
    assertEqual(r.score, 95, 'final Critic score above the bar');
    assert(r.trace.some(t => t.node === 'Scout') && r.trace.some(t => t.node === 'Critic'), 'trace records the path');
  });

  await atest('graph: conditional route — no job → no letter (ends after Matcher)', async () => {
    const mockLlm = { isAvailable: () => true, chat: async () => 'x' };
    const r = await graph.runGraph({ cvText: 'siem', profile: {}, job: null, jobDescription: '' }, gDeps, mockLlm, noRag);
    assertEqual(r.coverLetter, '', 'routed straight to END');
    assertEqual(r.revisions, 0, 'Writer never ran');
  });

  await atest('graph: per-node error isolation (LLM failure → trace, no crash)', async () => {
    const throwLlm = { isAvailable: () => true, chat: async () => { throw new Error('boom'); } };
    const r = await graph.runGraph({ cvText: 'siem', profile: {}, job: { title: 'X' }, jobDescription: 'x' }, gDeps, throwLlm, noRag);
    assert(r.trace.some(t => /error/i.test(t.note)), 'error captured in the trace, pipeline still returns');
  });

  await atest('graph: a Critic that could not run reports no score, it does not invent one', async () => {
    const throwLlm = { isAvailable: () => true, chat: async () => { throw new Error('boom'); } };
    const r = await graph.runGraph({ cvText: 'siem', profile: {}, job: { title: 'X' }, jobDescription: 'x' }, gDeps, throwLlm, noRag);
    assertEqual(r.scored, false, 'the run is marked unscored');
    assertEqual(r.score, null, 'no grade is handed to the caller');
  });

  const total = passed + failed + skipped;
  const bar   = '─'.repeat(50);

  console.log('\n' + c.dim(bar));
  console.log(c.bold('  Test Results'));
  console.log(c.dim(bar));
  console.log(`  ${c.green('✓ Passed')}  ${String(passed).padStart(3)}/${total}`);
  if (failed  > 0) console.log(`  ${c.red('✗ Failed')}  ${String(failed).padStart(3)}/${total}`);
  if (skipped > 0) console.log(`  ${c.yellow('⊘ Skipped')} ${String(skipped).padStart(3)}/${total}`);
  console.log(c.dim(bar));

  if (failed === 0) {
    console.log(c.green(c.bold('\n  All tests passed — Sprint 1 + Multi-Agent architecture verified!\n')));
  } else {
    console.log(c.red(c.bold(`\n   ${failed} test(s) failed — please review above.\n`)));
    process.exit(1);
  }
})();
